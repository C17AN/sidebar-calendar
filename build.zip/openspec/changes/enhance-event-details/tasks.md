# Implementation Tasks

- [x] Update `popup.html`: Add `#edit-event-dialog` with form fields. <!-- id: 0 -->
- [x] Update `style.css`: Style the edit dialog and update event card layout for new fields. <!-- id: 1 -->
- [x] Update `utils/storage.js`: Add `updateItem` function. <!-- id: 2 -->
- [x] Update `popup.js`: Implement "Edit" click handler, Dialog logic, and Save logic. <!-- id: 3 -->
- [x] Update `popup.js`: Update `renderNextUp` to show Time/Location/Link. <!-- id: 4 -->