# Implementation Tasks

- [x] Update `style.css`: Import Pretendard font and remove excessive container padding. <!-- id: 0 -->
- [x] Update `popup.html`: Add Language selection in Settings Dialog. <!-- id: 1 -->
- [x] Update `popup.js`: Implement `i18n` dictionary and translation logic. <!-- id: 2 -->
- [x] Update `popup.js`: Update `renderDashboard` to respect `settings.language`. <!-- id: 3 -->