# Localization

## ADDED Requirements

### Requirement: Language Setting
The application MUST allow the user to switch between Korean and English.

#### Scenario: Switch to Korean
- Given the settings dialog is open
- When the user selects "Korean"
- Then the UI text (Headers, Month Names, Placeholders) changes to Korean immediately.
