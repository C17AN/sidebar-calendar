# Implementation Tasks

- [x] Update `style.css`: Apply `user-select: none` to `body` and `user-select: text` to inputs. <!-- id: 0 -->
- [x] Update `utils/gcal.js`: Add improved error logging and alert the exact error message (e.g. from `chrome.runtime.lastError`). <!-- id: 1 -->
- [x] Update `manifest.json`: Ensure `oauth2` scopes are correct and formatted properly. <!-- id: 2 -->