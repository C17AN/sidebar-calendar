# Implementation Tasks

- [x] Update `style.css`: Replace the hardcoded `#2a2c3d` hover color with `filter: brightness(1.2)` or similar logic that respects the theme. <!-- id: 0 -->