# Implementation Tasks

- [x] Update `content.js`: Modify `mouseup` listener to ignore clicks where `event.target` is the `shadowHost`. <!-- id: 0 -->