# Localization

## MODIFIED Requirements

### Requirement: Floating UI Localization
The Floating UI on web pages MUST use the language selected in the extension settings.

#### Scenario: Switch to Korean
- Given the user selects Korean in the extension
- When the user selects text on a web page
- Then the floating button text is "D-Day 추가" (or similar Korean translation).
