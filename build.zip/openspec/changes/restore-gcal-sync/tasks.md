# Implementation Tasks

- [x] Update `popup.js`: Import `syncToCalendar` and add a "Sync" button to the `renderNextUp` event cards. <!-- id: 0 -->
- [x] Update `popup.js`: Implement the click handler for Sync, including error handling and user alerts. <!-- id: 1 -->
- [x] Create `SETUP.md`: Document the steps to generate a Google Cloud Client ID and update `manifest.json`. <!-- id: 2 -->