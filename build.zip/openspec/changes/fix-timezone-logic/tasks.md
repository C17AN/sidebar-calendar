# Implementation Tasks

- [x] Update `popup.js`: Replace UTC `toISOString` with Local Time string construction in `renderNextUp`. <!-- id: 0 -->