# Navigation

## MODIFIED Requirements

### Requirement: Open Side Panel from Content
The system MUST open the extension Side Panel when the user interacts with the reminder pill.

#### Scenario: Click Pill
- Given the "Today's Reminder" pill is visible
- When the user clicks the pill body
- Then the Side Panel opens for the current tab.
