# Input Behavior

## MODIFIED Requirements

### Requirement: Enter Key Submission
The system MUST allow submitting the "Add D-Day" form using the Enter key.

#### Scenario: Press Enter
- Given the user is typing a title in the floating input
- When the user presses the Enter key
- Then the item is saved
- And the overlay closes.
