# Implementation Tasks

- [x] Update `content.js`: Ensure `syncSettings` is called correctly and state is reactive. <!-- id: 0 -->
- [x] Update `theme.css`: Modify Light Mode `--bg-card` or add a specific `--bg-settings-btn` to improve contrast. <!-- id: 1 -->
- [x] Update `popup.js`: Double-check "System" mode implementation for edge cases. <!-- id: 2 -->