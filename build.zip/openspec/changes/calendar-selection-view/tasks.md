# Implementation Tasks

- [x] Update `popup.js`: Add `selectedDateStr` state and toggle logic in `renderCalendar`. <!-- id: 0 -->
- [x] Update `popup.js`: Modify `renderNextUp` to handle filtered mode and update labels dynamically. <!-- id: 1 -->
- [x] Update `style.css`: Add styles for `.day-cell.selected`. <!-- id: 2 -->
- [x] Update `popup.js`: Add localized label for "[Date] Schedule". <!-- id: 3 -->