# Implementation Tasks

- [x] Update `manifest.json` to include `sidePanel` permission and configuration, removing `default_popup`. <!-- id: 0 -->
- [x] Update `background.js` to configure `openPanelOnActionClick`. <!-- id: 1 -->