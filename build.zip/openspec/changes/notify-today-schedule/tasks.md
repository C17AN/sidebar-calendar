# Implementation Tasks

- [x] Update `background.js` to calculate today's item count and update `chrome.action.setBadgeText`. <!-- id: 0 -->
- [x] Update `content.js` to read storage on load, check for today's items, and render the Floating Reminder Pill. <!-- id: 1 -->