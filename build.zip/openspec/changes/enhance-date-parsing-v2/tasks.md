# Implementation Tasks

- [x] Update `utils/dateParser.js` to fix `new RegExp` escaping and add support for `YY` and `DD/MM/YYYY`. <!-- id: 0 -->
- [x] Update `content.js` with the identical parsing logic. <!-- id: 1 -->