# Implementation Tasks

- [x] Rewrite `theme.css` with the new Dark Mode variables. <!-- id: 0 -->
- [x] Update `popup.html` to reflect the new DOM structure (Header, Grid, Next Up, Footer). <!-- id: 1 -->
- [x] Rewrite `style.css` to implement the dark styling and layout. <!-- id: 2 -->
- [x] Update `popup.js` to implement `renderMonthlyGrid` and `renderNextUpList`. <!-- id: 3 -->