# Implementation Tasks

- [ ] Update `popup.js`: Remove `onclick` from `titleHtml` template string. <!-- id: 0 -->
- [ ] Update `popup.js`: Add logic to find the link element inside `card` and add `click` listener with `stopPropagation`. <!-- id: 1 -->
